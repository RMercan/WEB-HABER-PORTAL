namespace News365.Core.Entities;

public abstract class Entity : IEntity
{
    
    public Guid Id { get; set; }
       
}
