using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace News365.Core.Entities
{
    public interface IDTO
    {
        
    }
}