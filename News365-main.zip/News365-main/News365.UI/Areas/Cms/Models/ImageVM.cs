﻿namespace News365.UI.Areas.Cms.Models;
public class ImageVM
{
    public string Image { get; set; }
}