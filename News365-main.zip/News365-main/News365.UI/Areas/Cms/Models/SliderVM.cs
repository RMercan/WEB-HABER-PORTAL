﻿using News365.Entities.Concrete;

namespace News365.UI.Areas.Cms.Models;
public class SliderVM
{
    public Slider Slider { get; set; }

}