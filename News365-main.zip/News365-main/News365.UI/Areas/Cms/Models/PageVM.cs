using News365.Entities.Concrete;

namespace News365.UI.Areas.Cms.Models;

public class PageVM
{
  public Page Page { get; set; }
}